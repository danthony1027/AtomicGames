package com.beust.jcommander;

public class ArgsRequiredWrongMain {
  @Parameter(required = true)
  public String[] file;
}